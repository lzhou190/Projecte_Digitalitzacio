\# Com accedir a l'App des d'altres dispositius (Sense instal·lar Streamlit)



No cal instal·lar Streamlit ni Python als altres dispositius. L'ordinador on tens el codi actua com un servidor web i els altres es connecten mitjançant el navegador.



\## 1. Mateixa xarxa Wi-Fi (L'opció més ràpida)

Si ambdós dispositius estan connectats al mateix Wi-Fi:



1\. \*\*Executa l'app\*\* al teu ordinador:

&#x20;  ```bash

&#x20;  cd menu\_intelligent

&#x20;  source venv/bin/activate

&#x20;  streamlit run app\_millorat.py

&#x20;  ```

2\. Al terminal veuràs la \*\*Network URL\*\* (ex: `http://192.168.122.79:8501`).

3\. \*\*Obre el navegador\*\* a l'altre dispositiu i escriu aquesta adreça.



\## 2. Streamlit Community Cloud (Gratuït i Permanent)

Per tenir l'app disponible a tot el món:



1\. Puja el codi a \*\*GitHub\*\*.

2\. Registra't a \[share.streamlit.io](https://share.streamlit.io/).

3\. Connecta el repositori i l'app estarà en línia amb un enllaç tipus `la-teva-app.streamlit.app`.



\## 3. Tunneling amb ngrok (Per a proves remotes ràpides)

Si vols compartir l'app sense pujar-la al núvol i sense estar al mateix Wi-Fi:



1\. Instal·la `ngrok` a l'ordinador principal.

2\. Executa `ngrok http 8501`.

3\. Utilitza l'enllaç públic que et proporcioni (ex: `https://xyz.ngrok-free.app`).



